# Disable Headphone Safety Warning

A minimal KernelSU/APatch systemless module for Android devices that disables Android's safe headphone volume warning and safe-volume enforcement.

## What it changes

The module adds the following system properties:

```properties
audio.safemedia.bypass=true
audio.safemedia.force=false
audio.safemedia.csd.force=false
```

No APK, accessibility service, LSPosed hook, or background daemon is used.

## Installation

1. Download the module ZIP from the project's Releases page.
2. Install it through KernelSU Manager or APatch.
3. Reboot the device.

## Uninstallation

Disable or remove the module from KernelSU Manager/APatch and reboot.

## Important

This module does more than hide the warning dialog. It disables Android's safe-media volume enforcement as well.

Listening to headphones at excessive volume can cause permanent hearing damage. Use this module at your own risk.

## Compatibility

- KernelSU
- APatch
- Android versions where these `audio.safemedia.*` properties are honored by the audio stack
